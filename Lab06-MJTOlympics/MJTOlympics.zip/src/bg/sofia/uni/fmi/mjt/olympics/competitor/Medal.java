package bg.sofia.uni.fmi.mjt.olympics.competitor;

public enum Medal {
	GOLD, SILVER, BRONZE
}	
