package bg.sofia.uni.fmi.mjt.olympics.competitor;

public enum Medal {
	BRONZE, SILVER, GOLD
}	
