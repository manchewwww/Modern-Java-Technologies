package bg.sofia.uni.fmi.mjt.glovo.delivery;

public enum ShippingMethod {
    FASTEST,
    CHEAPEST
}